#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "leak_detector_c.h"
//#include "leak_detector_c.c"



#define MAX_ARRAY_SIZE 100000000
#define TEST_CASE 25
#define MAX_BOOKS 100000
#define SIZE 100000
#define MAXVAL  100000000000000

void Print_Array(int values[], int length);
void Fill_Array(int values[], int length, int max);
void MergeSort(int values[], int start, int end);
void Merge(int values[], int start, int middle, int end);
int Is_Sorted(int values[], int length);
void arrayCopy(int from[], int to[], int size);
int arrayCounter(int arr[], int length, int s, int y);


FILE* inFile;
FILE* outFile;
int main(void) {
  
  clock_t begin = clock();
  atexit(report_mem_leak);
  inFile = fopen("in.txt", "r");
  outFile = fopen("out.txt", "w");
  
  
  int c;
  long long int *n, *L;
  int *q;
  int *newL;


  fscanf(inFile, "%d", &c);
  //printf("%d\n", c);
  n = (long long int*) malloc(c * sizeof(int));
  L = (long long int*) malloc(*n * sizeof(int));
  newL = (int*) malloc(c * sizeof(int));
  
  
  if(c <= TEST_CASE)
  {
  
  for (int i = 0; i < c; i++)
  {
    
    fscanf(inFile,"%lld %lld", &n[i], &L[i]);
    //printf("%lld %lld\n", n[i], L[i]);

    q = (int*) malloc(n[i] * sizeof(int));

    if(n[i] <= MAX_BOOKS || L[i] <= MAXVAL)
    {  for(int j = 0; j < n[i]; j++)
      {
        fscanf(inFile,"%d", &q[j]);
        //newL[i] = q[i];
        //printf("%d ", q[j]);
        //Print_Array(&q[i-1], n[i]);
        //Print_Array(&q[j], n[i]);
      }
    
    //printf("\n");
    //Print_Array(q, n[i]);
    //Print_Array(&q[i], n[i]);
    //printf("\n");
    MergeSort(q, 0, n[i]-1);
    //Print_Array(q, n[i]);
    //printf("\n");

    arrayCounter(q, n[i], 0, L[i]);
    printf("\n");
    }
    else
    {
      exit(-1);
    }
    //free(newL);
    //free(n);
    free(q);
  }
  //free(q);
  free(newL);
  free(n);
  free(L);
}
  else
  {
  printf("Program Overflow");
  exit(0);
  }

    clock_t end = clock();
    double time_spent = ((double)(end - begin) / CLOCKS_PER_SEC);
    //printf("TIME SPENT: %.4fs", time_spent);
  //Print_Array(q, *n);
  return 0;
}

// Pre-condition: length is the length of the array values.
// Post-condition: all the numbers stored in values will be printed out,
//                 from the values stored in index 0 to index length-1.
void Print_Array(int values[], int length) {

    int i;
    for (i=0; i<length; i++)
        printf("%d ", values[i]);
    printf("\n");
}

// Pre-condition: length is the length of the array values and max<32767.
// Post-condition: the array values will be initialized with random values
//                 in between 1 and max.

// Pre-condition: values is of length length.
// Post-condition: Returns 1, iff values is in non-decreasing order.
int Is_Sorted(int values[], int length) {
    
    int i;
    
    // Return false if any adjacent pair is out of order.
    for (i=0; i<length-1; i++)
        if (values[i] > values[i+1])
            return 0;
            
    return 1;
}

// Pre-condition: start and end are valid indexes to the array values.
// Post-condition: The values in the array starting from index start to
//                 index end will be in non-decreasing sorted order.
void MergeSort(int values[], int start, int end) {

    int mid;
  
    // Check if our sorting range is more than one element.
    if (start < end) {

        mid = (start+end)/2;
    
        // Sort the first half of the values.
        MergeSort(values, start, mid);
    
        // Sort the last half of the values.
        MergeSort(values, mid+1, end);
    
        // Put it all together.
        Merge(values, start, mid+1, end);
    }
}

// Pre-condition: start, middle and end are valid indexes to the array values,
//                with middle >= start and middle <= end. Also, the values from
//                index start to middle are sorted AND the values from middle+1
//                to end are sorted.
// Post-condition: The values in the array starting from index start to
//                 index end will be in non-decreasing sorted order.
void Merge(int values[], int start, int middle, int end) {

    //printf("merge %d, %d, %d\n", start, middle, end);
    
    int *temp, i, length, count1, count2, mc;
  
    // Allocate the proper amount of space for our auxiliary array.
    length = end - start + 1;
    temp = (int*)calloc(length, sizeof(int) + 1);

    // These will be our indexes into our two sorted lists.
    count1 = start;
    count2 = middle;
  
    // Keeps track of our index into our auxiliary array.
    mc = 0;

    // Here we copy values into our auxiliary array, so long as there are 
    // numbers from both lists to copy.
    while ((count1 < middle) || (count2 <= end)) {

        // Next value to copy comes from list one - make sure list
        // one isn't exhausted yet. Also make sure we don't access index
        // count2 if we aren't supposed to.
        if (count2 > end || (count1 < middle && values[count1] < values[count2])) {
            temp[mc] = values[count1];
            count1++;
            mc++;
        }
    
        // We copy the next value from list two.
        else {
            temp[mc] = values[count2];
            count2++;
            mc++;
        }
    }

    // Copy back all of our values into the original array.
    for (i=start; i<=end; i++)
        values[i] = temp[i - start];

    // Don't need this space any more!
    free(temp);
}

void arrayCopy(int from[], int to[], int size)
{
  int j;
  for (j = 0; j < size; j++)
  {
    to[j] = from[j];
  }
}

int arrayCounter(int arr[], int length, int s, int y){
  int counter = 0;
  int total = 0;
  if(length > s)
  {

    for(int i = 0; i < length; i++)
    {
      total += arr[i];
      //printf("%d\n", total);
      //arrayCounter(arr, length, s+1);
      //arrayCounter(arr, length + 1);
      //printf("%d", total);
      if(total <= y)
        counter++;
    }
    total = 0;
  }
  printf("%d", counter);
  return 1;
}



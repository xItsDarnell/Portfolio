package Matter;

public class Element_Check {

		//Tests the inheritance between the parent class State and the Element classes.
		public static void main(String[] args) {

	       Solid ice = new Solid("Ice", "Blue", 15);
	       System.out.println("Name: " + ice.getName() + "\nColor: " + ice.getColor());
	       System.out.println("Mass of Ice (in Grams): " + ice.getMass());
	       System.out.println("Kinetic Energy of State (in Joules) : " + ice.getParticleMovement());

	       System.out.println();

	       Liquid water = new Liquid("Ocean Water", "Blue", 52);
	       System.out.println("Name: "+ water.getName() + "\nColor: " + water.getColor());
	       System.out.println("Volume of Water (in Mililiters): " + water.getVolume());
	       System.out.println("Kinetic Energy of State (in Joules) : " + water.getParticleMovement());
	       
	       System.out.println();
	       
	       Gas steam = new Gas("Steam", "White", 9.8);
	       System.out.println("Name: " + steam.getName() + "\nColor: " + steam.getColor());
	       System.out.println("Vapor Level of Steam (in Vapor Levels) " + steam.getVaporLevel());
	       System.out.println("Kinetic Energy of State (in Joules) : " + steam.getParticleMovement());
	   }
	}
package Matter;

public class Solid extends State
{
   private double mass;
   
   //Constructor for Solid State information.
   public Solid(String name, String color,double mass) {
       super(name, color);
       this.mass=mass;
   }
   //Override getParticleMovement method of the State abstract class
   public String getParticleMovement()
   {
       return "2.030";
   }
   
   //Retrieves + Returns the mass of the solid element for the system.
   public double getMass()
   {
       return mass;
   }
   public void setMass(double mass)
   {
       this.mass = mass;
   }
}
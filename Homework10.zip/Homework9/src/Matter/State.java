package Matter;

public abstract class State
{
   //Instance variables 
   //Checking which state of matter has a name and color.
   private String name;
   private String color;
   public State(String name, String color)
   {
       this.name=name;
       this.color=color;
   }
   //Abstract method
   public abstract String getParticleMovement();
   
   //Returns the name for Element Check.
   public String getName()
   {
       return name;
   }  
   
   //Function sets up the name.
   public void setName(String name)
   {
       this.name = name;
   }
   
   //Function sets up the color.
   public void setColor(String color)
   {
       this.color = color;
   }
   
   //Returns the color for Element_Check.
   public String getColor()
   {
       return color;
   }
}
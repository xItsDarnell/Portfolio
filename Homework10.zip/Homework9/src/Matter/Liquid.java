package Matter;

public class Liquid extends State
{
   private double volume;
   
   //Constructor for Liquid State information.
   public Liquid(String name, String color,double volume) {
       super(name, color);
       this.volume=volume;
   }
   
   //Override getParticleMovement method of the Fruit abstract class
   public String getParticleMovement()
   {
       return "4.168";
   }
   
   //Retrieves + Returns the volume of the liquid element for the system.
   public double getVolume()
   {
       return volume;
   }
   public void setVolume(double volume)
   {
       this.volume = volume;
   }
}
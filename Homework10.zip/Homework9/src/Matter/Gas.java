package Matter;

public class Gas extends State
{
   private double vaporLevel;
   
   //Constructor for Gas State information.
   public Gas(String name, String color,double vaporLevel) {
       super(name, color);
       this.vaporLevel=vaporLevel;
   }
   
   //Override getParticleMovement method of the Fruit abstract class
   public String getParticleMovement()
   {
       return "200";
   }
   
   //Retrieves + Returns the Vapor Level of the solid element for the system.
   public double getVaporLevel()
   {
       return vaporLevel;
   }
   public void setVaporLevel(double vaporLevel)
   {
       this.vaporLevel = vaporLevel;
   }
}
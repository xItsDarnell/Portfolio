package OneD_ArrayAssignment;

//Importation of the scanner, array, & other Java library.
import java.util.Arrays;
import java.util.Scanner;
import java.lang.Math;
import java.lang.System;

public class ArraySimulation {

	public static void main(String[] args) {
		
		//Create an array of 100 integers.
		//Store 100 random integers (between 1 and 100) in the array.
		int i, n;
		int[] a = new int[100];
		
		 for(i=0;i<100;i++)
	           a[i]=(int)(Math.random()*100)+1;
		 
		 Print(a);
		 Sort(a);
		 Print(a);
		 
		 System.out.println("Enter a number between 1 and 100: ");
		 @SuppressWarnings("resource")
		 Scanner sc=new Scanner(System.in);
		 n=sc.nextInt();
		 Search(a,a.length);
	       
		 System.out.println("Frequency of each number in the array: ");
	     Frequency(a, n);
	       
	     Average(a);
	     Highest(a);
	     Lowest(a);
		
	}
		//Displays the lowest number in the array.
	  	private static void Lowest(int[] a) {
		  int minimum=100;
	       for(int i:a) 
	           if(i < minimum )  
	               minimum=i;
	       
	       System.out.println("The lowest number in the array is: " + minimum);
	  }
	  
	  //Displays the highest number in the array.
	  private static void Highest(int[] a) {
		  int maximum=100;
	       for(int i:a) 
	           if(i > maximum )  
	               maximum=i;
	     
	       System.out.println("The higest number in the array is: " + maximum);
	  }
	  
	  //Displays the average of the numbers in the array.
	  private static void Average(int[] a) {
		  int total=0;
	       for(int i:a) 
	           total=total+i;
	       
	       System.out.println("The average of the numbers is: " + total/a.length);
	  }
	  
	  //Displays the frequency of each number from 1 to 100 and the number of times each is found in the array.
	  private static void Frequency(int[] array, int n) {
		  
		  int i, j;
		  boolean checkElement[] = new boolean[n];
		  Arrays.fill(checkElement, false);
		  
		  for (i = 0; i < n; i++) 
			  if (checkElement[i] == true)
				   continue;
	
		  int count = 1; 
		  for (j = i + 1; j < n; j++)
			   if (array[i] == array[j]) 
				   {
				   	checkElement[j] = true;
				   	count++;
				   }
			   	
		   System.out.println(array[i] + " " + count);
		   }
	  
	  //Searches the array for that number and then display  "Found" or "Not Found" message depending on the number the user inputs.
	  private static void Search(int[] a, int n) { 
		  for(int i:a) 
	           if(i == n) {
	               System.out.println("Found");
	               return;
	           }
	       System.out.println("Not Found");
	   }
	  
	  //Sorts the numbers of the array in ascending order.
	  private static void Sort(int[] a) {
		int temp;
		
		for (int i = 1; i < a.length; i++)
			for (int j = i; j > 0; j--) {
				if (a[j] < a[j - 1]) {
				temp = a[j];
				a[j] = a[j - 1];
				a[j - 1] = temp;
		     }
		   }
	  }
	  //Prints the elements inside of the array.
	  private static void Print(int[] a) {
		  for(int i : a) {
	           System.out.print(i+" ");
	       }
	       System.out.println();
	  }

}
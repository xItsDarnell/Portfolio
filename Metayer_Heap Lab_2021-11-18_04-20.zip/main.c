#include <stdio.h>
#include <stdlib.h>



int isHeap_recursive(int array[], int i, int n)
{
  if(i >= n || n <= 0)
    return 1;

  if((2*i+1) < n)
  {
    if(array[2*i+1] < array[i])
      return 0;
  }
  if((2*i+2) < n)
  {
    if(array[2*i+2] < array[i])
      return 0;
  }

  return isHeap_recursive(array, 2*i+1, n) && isHeap_recursive(array, 2*i+2, n);
}


int isHeap_iter(int array[], int n)
{
  for(int i = 0; i <= (n-2)/2; i++)
  {
    if(array[2*i+1] < array[i])
      return 0;

    if(array[2*i+2] < array[i])
      if(array[2*i+2] != 0)
        return 1;
      
    //before checking if arr[2*i + 2] < array[i], we need to make sure that the index
    //for the right child exist (make sure that we are not going out of bounds)
  }
}
int main(void) 
{
  int n, *arrayB;

  printf("How many entries? ");
  scanf("%d", &n);

  arrayB = malloc(n * sizeof(int));

  printf("Enter %d entries: ", n);
  for(int i = 0; i < n; i++)
  {
    scanf("%d", &arrayB[i]);
  }

  isHeap_recursive(arrayB, 0, n) ? printf("Recursive says Yes!\n") : printf("Recursive says No!\n");

  isHeap_iter(arrayB, n) ? printf("Iterative says Yes!") : printf("Iterative says No!\n");

  free(arrayB);
  return 0;
}
package BeerAssigment;

//Importation of the scanner library.
import java.util.*;
import java.text.DecimalFormat;


package BeerAssigment;

import java.text.DecimalFormat;
import java.util.Scanner;

public class BeerCalculation {
		
	public static void main(String[] args) {
		
	//Initializing the Beer Consumption, Calories & total amount.
	double beerConsumption, caloriesFromBeer, totalAmount, weightGain;
	double beerCount, beerPrice;
	try (Scanner sc = new Scanner(System.in))
		{
		DecimalFormat df = new DecimalFormat("####0.00");
		
		//Scanner protocol to declare amount of beer from the user and how much they pay per can.
			System.out.print("On average, how many beers will you consume each day?\n ");  
			beerCount= sc.nextDouble();  
			
			System.out.print("On average, how many will you pay for each can of beer?\n ");  
			beerPrice= sc.nextDouble(); 
			

			totalAmount = beerPrice * beerCount;
			
			//Amount of Pounds gained from beer consumption.
			weightGain = beerCount * 15;
			
			//Calculating the total consumption of beer in a year.
			beerConsumption = beerCount * 365;
			
			//Program calculates the amount of calories that the user intakes in one year.
			caloriesFromBeer = beerConsumption * 150;
			
			System.out.println("That is approximately "+df.format(beerConsumption)+" beers in one year.");
			System.out.println("In one year, you will consume approximately " +df.format(caloriesFromBeer)+" calories from beer alone.");
			System.out.println("Without diet or exercise to counter these calories, you can expect to gain " +df.format(weightGain)+ " pounds from drinking that much beer this year.");
		}
	}
}

/* COP 3502C Assignment 6
This program is written by: Dawnelle Metayer */
#define MAXNAME_STYLISTS 10
#define INIT_SIZE 10
#define MAXNAME 20
#define SIZE 100
#define NUM_TEST_INSERTS 150
#define NUM_TOTAL_OPS 10000000
#define PRINT 0

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "leak_detector_c.h"

typedef struct heapStruct {
    int* heaparray;
    int capacity;
    int size;
}heapStruct;

typedef struct Customer {
    char name[MAXNAME+1];
    int assigned_Stylist;
    char prefered_Stylist[MAXNAME+1];
    int loyalty_points;
    int service_Time;
    int arrive_Time;
} Customer;

typedef struct stylist {
    char name[MAXNAME+1];
    heapStruct* waitingList;
    Customer* current;
    int timeFree;
} stylist;


// Used to create a heap.
heapStruct *initHeap();
heapStruct * initHeapfromArray(int* values, int length);
void heapify(struct heapStruct *h);

// Helper functions
void percolateDown(heapStruct *h, int index);
void percolateUp(heapStruct *h, int index);
int insert(heapStruct *h, int value);

// Two key functions to implement priority queue.
int removeMin(heapStruct *h);
void printHeap(heapStruct *h);

// More helper functions.
void swap(heapStruct *h, int index1, int index2);
int minimum(int a, int indexa, int b, int indexb);
void freeHeap(heapStruct *h);


void AddStylist(stylist* sPtr, char* sName);
int retrieveStyl(stylist dressers[], char person[], int styler_num);
void add_Customer(stylist* sPtr, Customer* cPtr);
int findMinimum(stylist dressers[], int styler_num);
int waitTime(stylist* sPtr);
int findTimeStop(stylist dressers[], int styler_num);

// Runs a heap sort.
void sort(int values[], int length);

FILE* inFile;
FILE* outFile;
int main(void) {
  atexit(report_mem_leak);
  inFile = fopen("in.txt", "r");
  outFile = fopen("out.txt", "w");
  int customer_num, styler_num;
  fscanf(inFile, "%d %d", &customer_num, &styler_num);
  stylist dressers[MAXNAME_STYLISTS];
  for (int i=0; i < styler_num; i++) 
  {
        char get[MAXNAME+1];
        fscanf(inFile, "%s", get);
        AddStylist(&dressers[i], get);
    }

    // Where we will store the Customers.
    Customer** customer_list = malloc(sizeof(Customer*)*customer_num);

    // Read the Customers in.
    for (int i=0; i<customer_num; i++) {

        // Make room.
        customer_list[i] = malloc(sizeof(Customer));

        // Read everything in.
        fscanf(inFile, "%d %s %s %d %d", &(customer_list[i]->arrive_Time), customer_list[i]->name, customer_list[i]->prefered_Stylist, &(customer_list[i]->loyalty_points), &(customer_list[i]->service_Time));

        // Default this to not getting the stylist.
        customer_list[i]->assigned_Stylist = 0;
    }

    // cIdx is index into customer_list.
    int cIdx = 0;

    // Event loop, we'll get out another way.
    while (1) {

        // Get the next time to enqueue a Customer.
        int nextInLine = 2000000000;
        if (cIdx < customer_num)
            nextInLine = customer_list[cIdx]->arrive_Time;

        // See which line finishes next.
        int nextFinLine = findTimeStop(dressers, styler_num);

        // No one to put in line and no one getting hair cut; we're done!
        if (nextFinLine == -1 && nextInLine == 2000000000) break;

        // Process adding someone into a line.
        if (nextFinLine == -1 || nextInLine <= dressers[nextFinLine].timeFree) {

            // First figure out which line to add them into.
            int line = -1;

            // See if their preferred stylist is there.
            if (strcmp(customer_list[cIdx]->prefered_Stylist, "NONE") != 0 &&
                        retrieveStyl(dressers, customer_list[cIdx]->prefered_Stylist, styler_num) >= 0)
                line = retrieveStyl(dressers, customer_list[cIdx]->prefered_Stylist, styler_num);

            // Otherwise, just do the usual rule.
            else
                line = findMinimum(dressers, styler_num);

            // Add this Customer to line number line. Update index.
            add_Customer(&dressers[line], customer_list[cIdx]);
            cIdx++;
        }

        // Process finishing a haircut.
        else {

            // This is the information requested.
            printf("%s %d %d %s\n", dressers[nextFinLine].current->name,
                   dressers[nextFinLine].timeFree, dressers[nextFinLine].current->loyalty_points,
                   dressers[nextFinLine].name);
            fprintf(outFile, "%s %d %d %s\n", dressers[nextFinLine].current->name,
                   dressers[nextFinLine].timeFree, dressers[nextFinLine].current->loyalty_points,
                   dressers[nextFinLine].name);

            // Put someone in the chair, if someone is waiting.
            if (dressers[nextFinLine].waitingList->size > 0) {
                dressers[nextFinLine].current = removeMin(dressers[nextFinLine].waitingList);
                dressers[nextFinLine].timeFree += dressers[nextFinLine].current->service_Time;
                dressers[nextFinLine].current->loyalty_points += dressers[nextFinLine].current->service_Time/10;
            }

            // Otherwise, indicate that no one is in this line.
            else
                dressers[nextFinLine].current = NULL;
        }
    }

    // Clean up time - first each heap.
    for (int i=0; i<styler_num; i++)
        freeHeap(dressers[i].waitingList);

    // Then each Customer.
    for (int i=0; i<customer_num; i++)
        free(customer_list[i]);

    // Then the Customer array.
    free(customer_list);

    return 0;
}
// Initialize an empty heap with a capacity of SIZE.
struct heapStruct* initHeap() {

    struct heapStruct* h;

    // Allocate space for the heap and set the size for an empty heap.
    h = (struct heapStruct*)(malloc(sizeof(struct heapStruct)));
    h->capacity = SIZE;
    h->heaparray = (int*)malloc(sizeof(int)*(SIZE+1));
    h->size = 0;
    return h;
}

// Frees the struct pointed to by h.
void freeHeap(struct heapStruct *h) {
     free(h->heaparray);
     free(h);
}

// Initializes the heap using the first length number of items in the array
// values.
struct heapStruct * initHeapfromArray(int* values, int length) {

    int i;
    struct heapStruct* h;

    h = (struct heapStruct*)(malloc(sizeof(struct heapStruct)));
    // We allocate one extra slot, since slot 0 stays unused.
    h->heaparray = (int*)malloc(sizeof(int)*(length+1));

    // Just copy the values into our array.
    for (i=1; i<=length; i++)
        h->heaparray[i] = values[i-1];

    // This is the number of values we copied.
    h->size = length;

    // This takes our random values and rearranges them into a heap.
    heapify(h);
    return h;
}

// h points to a heap structure that has values inside of it, but isn't yet
// organized into a heap and does exactly that.
void heapify(struct heapStruct *h) {

    int i;

    // We form a heap by just running percolateDown on the first half of the
    // elements, in reverse order.
    for (i=h->size/2; i>0; i--)
        percolateDown(h, i);

}

// Runs percolate down on the heap pointed to by h on the node stored in index.
void percolateDown(struct heapStruct *h, int index) {

    int min;

    // Only try to percolate down internal nodes.
    if ((2*index+1) <= h->size) {

        // Find the minimum value of the two children of this node.
        min = minimum(h->heaparray[2*index], 2*index, h->heaparray[2*index+1], 2*index+1);

      // If this value is less than the current value, then we need to move
      // our current value down the heap.
        if (h->heaparray[index] > h->heaparray[min]) {
            swap(h, index, min);

            // This part is recursive and allows us to continue percolating
            // down the element in question.
            percolateDown(h, min);
        }
    }

    // Case where our current element has exactly one child, a left child.
    else if (h->size == 2*index) {

        // Here we only compare the current item to its only child.
        // Clearly, no recursive call is needed since the child of this node
        // is a leaf.
        if (h->heaparray[index] > h->heaparray[2*index])
            swap(h, index, 2*index);
    }
}

// Runs percolate up on the heap pointed to by h on the node stored in index.
void percolateUp(struct heapStruct *h, int index) {

    // Can only percolate up if the node isn't the root.
    if (index > 1) {

        // See if our current node is smaller in value than its parent.
        if (h->heaparray[index/2] > h->heaparray[index]) {

            // Move our node up one level.
            swap(h, index, index/2);

            // See if it needs to be done again.
            percolateUp(h, index/2);
        }
    }
}

// Inserts value into the heap pointed to by h. Returns 1 if the insert was
// successful, 0 otherwise.
int insert(heapStruct *h, int value) {

    int* temp;
    int* throwaway;
    int i;

    // Our array is full, we need to allocate some new space!
    if (h->size == h->capacity) {

        // Allocate new space for an array.
        h->heaparray = (int*)realloc(h->heaparray, sizeof(int)*(2*h->capacity+1));

        // Realloc failed so we quit.
        if (h->heaparray == NULL) return 0;

        // Double the capacity.
        h->capacity *= 2;
    }

    // Adjust all the necessary components of h, and then move the inserted
    // item into its appropriate location.
    h->size++;
    h->heaparray[h->size] = value;
    percolateUp(h, h->size);
}

int removeMin(heapStruct *h) {

    int retval;

    // We can only remove an element, if one exists in the heap!
    if (h->size > 0) {

        // This is where the minimum is stored.
        retval = h->heaparray[1];

        // Copy the last value into this top slot.
        h->heaparray[1] = h->heaparray[h->size];

        // Our heap will have one fewer items.
        h->size--;

        // Need to let this value move down to its rightful spot in the heap.
        percolateDown(h, 1);

        // Now we can return our value.
        return retval;
    }

    // No value to return, indicate failure with a -1.
    else
        return -1;
}

// For debugging purposes, lets us see what's in the heap.
void printHeap(struct heapStruct *h) {
    int i;

    for (i=1; i<=h->size; i++)
        printf("%d ", h->heaparray[i]);
    printf("\n");
}

// Swaps the values stored in the heap pointed to by h in index1 and index2.
void swap(struct heapStruct *h, int index1, int index2) {
    int temp = h->heaparray[index1];
    h->heaparray[index1] = h->heaparray[index2];
    h->heaparray[index2] = temp;
}

// Returns indexa if a < b, and returns indexb otherwise.
int minimum(int a, int indexa, int b, int indexb) {

    // Return the value associated with a.
    if (a < b)
        return indexa;

    // Return the value associated with b.
    else
        return indexb;
}

// Runs a heap sort by creating a heap out of the values in the array, and then
// extracting those values one-by-one from the heap back into the array in the
// proper order.
void sort(int values[], int length) {

     struct heapStruct *h;
     int i;

     // Create a heap from the array of values.
     h =  initHeapfromArray(values, length);
     length = h->size;

     // Remove these values from the heap one by one and store them back in the
     // original array.
     for (i=0; i<length; i++) {
         values[i] = removeMin(h);
     }
}


// Sets up the stylist pointed to by sPtr to have the name sName.
void AddStylist(stylist* sPtr, char* sName) {
    strcpy(sPtr->name, sName);
    sPtr->waitingList = initHeap();
    sPtr->current = NULL;
    sPtr->timeFree = -1;
}

// Returns the number of people waiting for the stylist pointed to by sPtr.
int waitTime(stylist* sPtr) {
    if (sPtr->current == NULL) return -1;
    return sPtr->waitingList->size;
}

// Adds the Customer pointed to by cPtr into the "line" for the stylist pointed to by sPtr.
void add_Customer(stylist* sPtr, Customer* cPtr) {

    // Update if this Customer got their stylist.
    if (strcmp(cPtr->prefered_Stylist, sPtr->name) == 0) cPtr->assigned_Stylist = 1;

    // No one in chair - go directly to the chair!
    if (sPtr->current == NULL) {
        sPtr->current = cPtr;
        sPtr->timeFree = cPtr->arrive_Time + cPtr->service_Time;
        cPtr->loyalty_points += (cPtr->service_Time/10);
    }

    // add to queue.
    else
        insert(sPtr->waitingList, cPtr);
}

// If person is working, returns the index person is stored in dressers, otherwise, returns -1.
int retrieveStyl(stylist dressers[], char person[], int styler_num) {

    // Look for this stylist - if we find them, return that index.
    for (int i=0; i<styler_num; i++)
        if (strcmp(dressers[i].name, person) == 0)
            return i;

    // Not working today!
    return -1;
}

// Returns the smallest line index of any of the dressers.
int findMinimum(stylist dressers[], int styler_num) {

    // Default to the first.
    int counter= 0;
    int waitingCounter = waitTime(&dressers[0]);

    // Update only if something is strictly better.
    for (int i=1; i<styler_num; i++) {
        if (waitTime(&dressers[i]) < waitingCounter) {
            waitingCounter = waitTime(&dressers[i]);
            counter= i;
        }
    }

    // Ta da!
    return counter;
}

// Returns the index of the hairdresser who is finishing a cut next.
int findTimeStop(stylist dressers[], int styler_num) {

    int counter= -1, curT = -1;

    // Go through each stylist.
    for (int i=0; i<styler_num; i++) {

        // No one here.
        if (dressers[i].current == NULL) continue;

        // Update if this is the first one or if this is better than what's been seen.
        if (counter== -1 || dressers[i].timeFree < curT) {
            counter= i;
            curT = dressers[i].timeFree;
        }
    }

    // Ta da!
    return counter;
}
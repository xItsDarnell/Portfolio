package Polymorphism;

public class PolymorphTest {

    public static void main(String[] args) {
    	
		//Create the classes Person, Athlete, BaseballPlayer
		//Create the classes FootballPlayer, HockeyPlayer, Golfer, SoccerPlayer
		//Create the doThis() method in each class
          BaseballPlayer Hank = new BaseballPlayer("Hank Hill", 34, "New York Yankees", "Pitch Hitter", "Right-handed\n");
          FootballPlayer Terry = new FootballPlayer("Terry Bogard", 20, "Los Angeles Rams", "Linebacker", "Defense\n");
          HockeyPlayer Mario = new HockeyPlayer("Mario Mario", 22, "Ottawa Senators", "Left Wing", "CCM Jetspeed FT2\n");
          Golfer Paula = new Golfer("Paula Smaoll", 29, "Nicklaus at Night", "Position 1", "SkillShare\n");
          SoccerPlayer Danilo = new SoccerPlayer("Danilo Devito", 25, "Liverpool F.C.", "Defense", "Goal Keeper\n");
           
          BaseballPlayer Barry = new BaseballPlayer("Barry West",28,"Pittsburgh Pirates","Pitcher","Both\n");
          FootballPlayer Peyton = new FootballPlayer("Peyton List",30,"Green Bay Packers","Quarterback","Offense\n");
          HockeyPlayer Wayne = new HockeyPlayer("Wayne " + "The Rock " + "Johnson",22,"Anaheim Ducks","Center Wing","Warrior Alpha DX SL\n");
          Golfer Phil = new Golfer("Phil Swift",35,"Weapons of Grass Destruction","Position2","Mizuno Corporation\n");
          SoccerPlayer Carlos = new SoccerPlayer("Carlos Santigo",27,"Arsenal F.C.","Defense","Goal Keeper\n");

          //Call each sport's doThis method (one at a time) passing each player.
          Hank.doThis();
          Terry.doThis();
          Mario.doThis();
          Paula.doThis();
          Danilo.doThis();
          
          Barry.doThis();
          Peyton.doThis();
          Wayne.doThis();
          Phil.doThis();
          Carlos.doThis();

          //Call the toString methods for each player object.
          System.out.println(Hank);
          System.out.println(Terry);
          System.out.println(Mario);
          System.out.println(Paula);
          System.out.println(Danilo);
          
          System.out.println(Barry);
          System.out.println(Peyton);
          System.out.println(Wayne);
          System.out.println(Phil);
          System.out.println(Carlos);

    }
}
package Polymorphism;

//All sport type objects have a method named doThis();
//A golfer is an athlete and a person.
//A golfer has a mainSponser.
public class Golfer extends Athlete{
    private String mainSponsor;

    public Golfer(String name, int age, String team, String position,String mainSponsor)

    {
          super(name,age,team,position);
          this.mainSponsor = mainSponsor;
    }
    
    //... in general, all sports have a doThis() method that displays something.
    public void doThis() {
          System.out.println("I putt it in the hole");
    }

    //Return the golfer's sponsor.
    public String toString()
    {
          return(super.toString()+"\nMain Sponsor : "+mainSponsor);
    }
}
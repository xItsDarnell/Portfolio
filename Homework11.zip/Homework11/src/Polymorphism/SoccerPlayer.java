package Polymorphism;

//All sport type objects have a method named doThis();
//A soccer player is an athlete and a person.
//A soccer player has these possible positions - goalKeeper, defender, midFielder, or forward.

public class SoccerPlayer extends Athlete{
    private String fieldPosition ;

    public SoccerPlayer(String name, int age, String team, String position, String fieldPosition)

    {
          super(name,age,team,position);
          this.fieldPosition = fieldPosition;
    }

    //... in general, all sports have a doThis() method that displays something.
    public void doThis() {
          System.out.println("I kick the ball\n");
    }
    
    //Return the soccer player's field position.
    public String toString()

    {
          return(super.toString()+"\nField position : "+fieldPosition);
    }
}
package Polymorphism;

//All sport type objects have a method named doThis();
//  A football player is an athlete and a person.
//A football player has a specialty.
//A football player's specialty is either Offense, Defense, or Special Teams.
public class FootballPlayer extends Athlete{
    private String specialty;

    public FootballPlayer(String name, int age, String team, String position, String specialty)

    {
          super(name,age,team,position);
          this.specialty = specialty;
    }

    //... in general, all sports have a doThis() method that displays something.
    public void doThis() {

          System.out.println("I tackle something");
    }

    //Return the football player's specialty.
    public String toString()

    {
          return(super.toString()+"\nSpecialty : "+specialty);
    }

}
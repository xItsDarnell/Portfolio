package Polymorphism;

//Since an athlete is a person, this class extends to person.java
//An athlete also has a team and position.

public abstract class Athlete extends Person{

    private String team;
    private String position;

    public Athlete(String name, int age, String team, String position)
    {

          super(name,age);
          this.team = team;
          this.position = position;
    }

   
  //Return player's team name & position.
    public String toString()
    {
          return(super.toString()+"\nTeam : "+team+"\nPosition : "+position);
    }

    public abstract void doThis();

}
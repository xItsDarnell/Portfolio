package Polymorphism;
// Declares that a person has a name and age.

public class Person{
    private String name;
    private int age;
    
//Sets up each player's information
    public Person(String name, int age)

    {
          this.name = name;
          this.age = age;
    }

//Return player's name and age
    public String toString()

    {
          return("Player Name + Age: "+name+"/"+age);
    }

}
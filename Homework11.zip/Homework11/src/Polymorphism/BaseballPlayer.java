package Polymorphism;

//All sport type objects have a method named doThis();
//A baseball player is an athlete and a person.
//A baseball player has a battingPosition.
//Baseball players either bat left-handed, right-handed or both.
public class BaseballPlayer extends Athlete{
    private String battingPosition;

    public BaseballPlayer(String name, int age, String team, String position, String battingPosition)

    {
          super(name,age,team,position);
          this.battingPosition = battingPosition;
    }

    //... in general, all sports have a doThis() method that displays something.
    public void doThis() 
    {
          System.out.println("I hit something");
    }

  //Return the baseball player's batting position.
    public String toString()
    {
          return(super.toString()+"\nBatting Position: "+battingPosition);
    }

}
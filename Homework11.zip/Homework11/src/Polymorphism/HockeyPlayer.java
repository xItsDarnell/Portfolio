package Polymorphism;

//All sport type objects have a method named doThis();
//A hockey player is an athlete and a person.
//A hockey player has a stickBrand.
public class HockeyPlayer extends Athlete{
    private String stickBrand;

    public HockeyPlayer(String name, int age, String team, String position, String stickBrand)
    {
          super(name,age,team,position);
          this.stickBrand = stickBrand;
    }

    //... in general, all sports have a doThis() method that displays something.
    public void doThis() {
          System.out.println("I sit in a penalty box");
    }
    
    //Return the hockey player'sstick brand.
    public String toString()
    {
          return(super.toString()+"\nStick Brand : "+stickBrand);
    }
}
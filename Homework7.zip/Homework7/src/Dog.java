public class Dog extends Animal{
	
	//Checks if the Dog is an Animal, has a name, breed type, and date of birth.
	private String name, breed;
	private int month, day, year;
	
	//Constructor for Dog information.
	public Dog(String name, String breed, double weight, double height, int month, int day, int year)
	{
	    super(weight, height);
	    this.name = name;
	    this.breed = breed;
	    this.month = month;
	    this.day = day;
	    this.year = year;
	}
	
	//Retrieves the name of the dog for the system.
	public void getName(String name)
	{
	    this.name = name;
	}
	
	//Returns the dog's name.
	public String getName()
	{
	    return name;
	}
	
	//Sets the breed type of the dog.
	public void setBreed(String breed)
	{
	    this.breed = breed;
	}
	
	//Returns the dog's breed.
	public String getBreed()
	{
	    return breed;
	}
	
	//Returns the dogs birth month, date, and year.
	public int getMonth(int month)
	{
		this.month = month;
		return month;
	}
	
	public int getDay(int day)
	{
		this.day = day;
		return day;
	}
	
	public int getYear(int year)
	{
		this.year = year;
		return year;
	}
	
	//Override for Animal from default.
	public String toString()
	{
		String result;
		result = ("Name: " + name + "\n" + super.toString() + "Birthdate: " + month +"/" + day + "/" + year + "\n");
	    return result;
	}
}
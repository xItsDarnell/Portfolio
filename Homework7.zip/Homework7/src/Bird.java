public class Bird extends Animal{

   private double wingSpan;
   private boolean canFly;
  
   //Constructor for Bird information.
   public Bird(double wingSpan, boolean canFly, double weight, double height)
   {
       super(weight, height);
       this.wingSpan = wingSpan;
       this.canFly = canFly;
   }
  
   //Sets the wing span of the Bird.
   public void setWingSpan(double wingSpan)
   {
       this.wingSpan = wingSpan;
   }
  
   //Checks if said bird can fly or not in a boolean sequence.
   public void setCanFly(boolean canFly)
   {
       this.canFly = canFly;
   }

   //Returns wing span as a string.
   public double getWingSpan()
   {
       return wingSpan;
   }
   //returns the boolean sequence from setCanFly.
   public boolean getCanFly()
   {
       return canFly;
   }
  
	//Override for Animal from default.
   public String toString()
   {
       String result;
	   result = ("Wing Span: "+wingSpan+" Can Fly : "+canFly+" "+super.toString());
	   return result;
   }
  
}
public class Animal {

   private double weight, height;
  
   //Checking if the animal has a height & weight.
   public Animal(double weight, double height)
   {
       this.weight = weight;
       this.height = height;
   }
  
   public Animal()
   {
       weight = 0;
       height = 0;
   }
  

   //Function sets up the weight.
   public void setWeight(double weight)
   {
       this.weight = weight;
   }
   
   //Function sets up the height.
   public void setHeight(double height)
   {
       this.height = height;
   }

   //Returns the weight for InheritanceTest.
   public double getWeight()
   {
       return weight;
   }
   
   //Returns the height for InheritanceTest.
   public double getHeight()
   {
       return height;
   }
  //Runs the result & minimize the amount of memory needed to be returned for InheritanceTest.
   public String toString()
   {
       String result;
       result =("Weight: "+weight+" Height: "+height +" ");
	   return result;
   }
}
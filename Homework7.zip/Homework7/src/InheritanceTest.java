public class InheritanceTest{

  
   public static void main(String[] args)
   {
       
       //Dimensions in Pounds & Inches.
	   Dog dog = new Dog("Cliffton ", "Golden Retriever ", 65.50, 24, 04, 12, 2012);
       Cat cat = new Cat ("Randull", 25, 9.8);
       Bird bird = new Bird (43.0, true, 69.0, 3.75);
      
       //Tests the inheritance between the parent class Animal and the object classes.
       System.out.println("Dog Info + Stats:\n " +dog);
       System.out.println("Cat Info + Stats:\n " +cat);
       System.out.println("Bird Info + Stats:\n "+bird);
   }
}
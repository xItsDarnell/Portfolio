public class Cat extends Animal{
  
   private String name;
   private int livesLeft;
  
   //Constructor for Cat information.
   public Cat(String name, double weight, double height)
   {
       super(weight, height);
       this.name = name;
       livesLeft = 9;
   }

   //Retrieves the name of the cat for the system.
   public void setName(String name)
   {
       this.name = name;
   }
   
   //Returns the cat's name.
   public String getName()
   {
       return name;
   }
  
   //Check to see if the cat is still alive, if not, then it is considered dead.
   public void trackLife()
   {

       if(livesLeft > 0)
           livesLeft--;
   }
   
   //Returns the amount of lives the cat has left.
   public int numLivesLeft()
   {
       return livesLeft;
   }
  
   //Override for Animal from default.
   public String toString()
   {
       String result;
	   result = ("Name: " +name+ " \nNumber of lives left: "+livesLeft+" "+super.toString() + "\n");
	   return result;
   } 
}
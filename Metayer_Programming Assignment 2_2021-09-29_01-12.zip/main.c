/* COP 3502C Assignment 2
This program is written by: Dawnelle Metayer */

#include <stdio.h>
#include <math.h>
#include <time.h>

//Defined numbers
#define TestCase 25
#define Backyard 8
#define Empty 0

//Globally Declared FILE pointer variables
FILE* inFile;
FILE* outFile;

//Each case will contain a single positive integer, n(n ≤ 8), representing that your backyard has 2n trees total.
//The intended run-times are O((2n)!) for n = 5, 
//O ((2n)!/2n) for n = 6, and 
//O ((2n)!/(2n * n!)) for n = 8
int n;

//Stores in the amount of trees for each recursive call in terms of each possible outcome.
int treePossibilities[TestCase];

//Each  input  case  will  contain  a  pair  of  space  separated  positive  integers,  xi  and yi, representing that the ith treetop is located at the coordinate (xi, yi), with -10000 ≤ xi, yi ≤ 10000
int coordinatePair[TestCase][Backyard];

float minimumDistance;

//Written file feeder function to take the input in of n and coordinatePairs.
//Takes in the integer c
//Does not return any paratemeters
void fileInput();

//This function calculates the distance between two differemnt points
void distanceCalculate();

//Aided with the help of SI Leader Matther, Dance Recital Lab, and Research on Permutation
//This function is used to get every single distance between all different coordinate combinations.
//The task is to use this function to grab all the distances and puck the smallest distance output.
void permutation();

int main(void){

    clock_t begin = clock();
    //Contains a single positive integer, c (c ≤ 25), representing the number of test cases to process. The test cases follow.
    int c = 0;
    inFile = fopen("in.txt", "r");
    outFile = fopen("out.txt", "w");

    fscanf(inFile, "%d", &c);
    fileInput(c);
    clock_t end = clock();
    double time_spent = ((double)(end - begin) / CLOCKS_PER_SEC);
    //printf("TIME SPENT: %.4fs", time_spent);
    
}

//
void fileInput(int c)
{
for(int i = 0; i < c; i++)
    {
      
      minimumDistance = 10000.0;
      
      fscanf(inFile, "%d", &n);
      for (int i = 1; i <= 2*n; i++)
      {

        fscanf(inFile, "%d %d", &coordinatePair[i][0], &coordinatePair[i][1]);
      }
      //Call Permutation();
      permutation();
      //Output a single floating point number rounded to exactly 3 decimal places, representing the minimum sum of distances possible if the //rope ladders are built between pairs of trees.
      printf("%0.3f\n", minimumDistance);
      fprintf(outFile, "%0.3f\n", minimumDistance);
    }
}

/* Function to take every permutations of the coordinate pairs
This function takes three tasks:
1. Checks if the treeArray is empty
2. Calls distanceCalculate in terms of i
3. Swaps the contents of i and j respectively to coordinatePair[] */
void permutation()
{
    //Declare and initialize i to zero.
    int i = 0;
    for(i = 1; i <= 2*n; i++)
    {
        //Checks if the ordered pair is empty. If so, this check breaks this for loop.
        if (treePossibilities[i] == Empty)
            break;
    }
    
    //This if statement checks if i is greater than the test case of 2*n. Runs distanceCalculate and returns that call.
    if (i > 2*n)
    {
        distanceCalculate();
        return;
    }
    
    //Initialize j to zero. This for loop goes through and makes sure that the j value of coordinatePair is empty or not.
    for (int j = 1; j <= 2*n; j++)
    {
        if (j != i && treePossibilities[j] == Empty)
        {
            //Implementing function swap through means of recursion
            treePossibilities[i] = j;
            treePossibilities[j] = i;
            //Calling Permutatuon Fuction
            permutation();
            //Setting the values of coordinatePair[] to zero. That way, the array will be empty when coming down the function again.
            treePossibilities[i] = 0;
            treePossibilities[j] = 0;
        }
    }
}

//finding the distance between two points which can be arbitrarily represented as points (x1,y1) & (x2​,y2​).

void distanceCalculate(){
    //squareCalculate is usd to calculate the total in distance while given the equation of (x2-x1)^2 + (y2-y1)^2
    //distance is calculated by taking the square root and returns the float value of squareCalculate
    int squareCalculate;
    float distance = 0;
    float dividen = 2;
    int i;
    for (i = 1; i <= 2*n; i++)
    {
        squareCalculate = (coordinatePair[i][0] - coordinatePair[treePossibilities[i]][0]) * (coordinatePair[i][0] - coordinatePair[treePossibilities[i]][0]) + (coordinatePair[i][1] - coordinatePair[treePossibilities[i]][1]) * (coordinatePair[i][1] - coordinatePair[treePossibilities[i]][1]);
        distance += sqrt((float)squareCalculate);
    }
    distance = distance/dividen;
    if(minimumDistance > distance)
        minimumDistance = distance;
}